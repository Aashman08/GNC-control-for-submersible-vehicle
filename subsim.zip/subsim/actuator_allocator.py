import numpy as np
from typing import Dict, Tuple

from .helper_functions import RateLimiter


class ActuatorAllocator:
    """Map controller outputs to actuator commands with saturation and rate limits.

    - Rudder and stern plane commands are saturated to safe ranges.
    - All actuators are passed through rate limiters to emulate actuator slew limits.
    """

    def __init__(self, limits: Dict[str, float]) -> None:
        self.rudder_rl = RateLimiter(limits["rudder_rate"])
        self.stern_rl = RateLimiter(limits["stern_rate"])
        self.thrust_rl = RateLimiter(limits["thrust_rate"])

        # Saturation bounds
        self.rmin: float = -0.7
        self.rmax: float = 0.7
        self.smin: float = -0.5
        self.smax: float = 0.5

    def allocate(
        self, u_pitch: float, u_yaw: float, thrust_sp: float, dt: float
    ) -> Tuple[float, float, float]:
        """Allocate pitch/yaw control efforts and thrust setpoint to actuators.

        Returns saturated and rate-limited commands (rudder, stern, thrust).
        """
        rudder = float(np.clip(u_yaw, self.rmin, self.rmax))
        stern = float(np.clip(u_pitch, self.smin, self.smax))

        rudder = self.rudder_rl.step(rudder, dt)
        stern = self.stern_rl.step(stern, dt)
        thrust = self.thrust_rl.step(float(np.clip(thrust_sp, 0.0, 1.0)), dt)

        return rudder, stern, thrust
