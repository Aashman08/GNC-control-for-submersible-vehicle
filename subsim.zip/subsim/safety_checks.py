"""Safety utilities for data validity checks."""

from typing import Dict, Any


def data_is_stale(sample: Dict[str, Any], max_age_s: float = 0.1) -> bool:
    """Return True if sample is marked stale.

    Note: This implementation only checks the 'stale' field. A timestamp-based
    check could be added later using 'ts' within the sample and 'max_age_s'.
    """
    return sample.get("stale", True)
