"""Command-line runner for the submarine simulation demo."""

import argparse
import os
import time
import yaml

import numpy as np
import matplotlib.pyplot as plt
from typing import Any, Dict
from .submarine_physics import SubmarinePhysics
from .sensor_emulator import SensorEmulator
from .sensor_filters import ComplementaryYaw, ComplementaryPitch
from .pid_controller import PID
from .actuator_allocator import ActuatorAllocator
from .helper_functions import wrap_angle

def load_settings() -> Dict[str, Any]:
    """Load YAML configuration bundled with the package."""
    here = os.path.dirname(__file__)
    with open(os.path.join(here, "simulation_settings.yaml"), "r") as f:
        return yaml.safe_load(f)

def run_demo(cfg: Dict[str, Any], duration: float, speed_profile=None) -> None:
    """Run a closed-loop demo: depth + heading hold with speed setpoint.

    Saves plots under a timestamped directory and shows figures at the end.
    """
    dt = cfg["sim"]["dt"]
    outdir = os.path.join(
        os.getcwd(), cfg["sim"]["save_dir"], time.strftime("%Y%m%d_%H%M%S")
    )
    os.makedirs(outdir, exist_ok=True)

    ocean = SubmarinePhysics(cfg)
    senses = SensorEmulator(cfg)

    yaw_f = ComplementaryYaw(alpha=0.02)
    pitch_f = ComplementaryPitch(alpha=0.02)

    yaw_pid = PID(**cfg["pid"]["yaw"])
    pitch_pid = PID(**cfg["pid"]["pitch"])
    depth_pid = PID(**cfg["pid"]["depth_outer"])

    mux = ActuatorAllocator(cfg["limits"])

    depth_target = cfg["setpoints"]["depth_m"]
    yaw_target = np.deg2rad(cfg["setpoints"]["heading_deg"])
    thrust_sp = cfg["setpoints"]["speed_mps"] / cfg["submarine"]["thrust_to_speed"]

    t: list[float] = []
    depth_hist: list[float] = []
    depth_target_hist: list[float] = []
    yaw_hist: list[float] = []
    yaw_target_hist: list[float] = []
    pitch_hist: list[float] = []
    pitch_target_hist: list[float] = []
    rud_hist: list[float] = []
    stern_hist: list[float] = []
    thrust_hist: list[float] = []
    speed_hist: list[float] = []

    tnow = 0.0
    while tnow < duration:

        # Apply speed profile if given
        if speed_profile:
            for t_change, new_speed in speed_profile:
                if tnow >= t_change:
                    thrust_sp = new_speed / cfg['submarine']['thrust_to_speed']
            thrust_sp = np.clip(thrust_sp, 0.0, 1.0)

        # Ground-truth state for sensors
        truth = {"yaw": ocean.yaw, "yaw_rate": ocean.yaw_rate, "pitch": ocean.pitch, "depth": ocean.depth}
        meas = senses.read(truth, dt)

        yaw_hat = yaw_f.update(meas["yaw_mag"], meas["gyro_z"], dt)
        pitch_hat = pitch_f.update(meas["pitch_accel"], gyro_y=0.0, dt=dt)
        depth_hat = meas["depth"]

        # Outer-loop depth to pitch, then pitch/yaw inner loops
        pitch_target = depth_pid.update(depth_target - depth_hat, dt)
        u_yaw = yaw_pid.update(wrap_angle(yaw_target - yaw_hat), dt)
        u_pitch = pitch_pid.update(pitch_target - pitch_hat, dt)

        # Allocate to actuators with saturation and rate limits
        rcmd, scmd, tcmd = mux.allocate(u_pitch, u_yaw, thrust_sp, dt)

        state = ocean.step(
            dt,
            rcmd,
            scmd,
            tcmd,
            yaw_disturb=cfg["sim"]["current_yaw_disturb"],
            vertical_disturb=cfg["sim"]["current_step"],
        )

        t.append(tnow)
        depth_hist.append(state["depth"])
        depth_target_hist.append(depth_target)
        yaw_hist.append(state["yaw"])
        yaw_target_hist.append(yaw_target)
        pitch_hist.append(state["pitch"])
        pitch_target_hist.append(pitch_target)
        rud_hist.append(rcmd)
        stern_hist.append(scmd)
        thrust_hist.append(tcmd)
        speed_hist.append(state['speed'])

        tnow += dt

    # Depth
    plt.figure()
    plt.title("Depth (m)")
    plt.plot(t, depth_hist, label="depth")
    plt.plot(t, depth_target_hist, label="depth_target")
    plt.xlabel("t (s)")
    plt.ylabel("depth (m)")
    plt.grid(True)
    plt.legend()

    # Yaw (Heading)
    plt.figure()
    plt.title("Yaw (rad)")
    plt.plot(t, yaw_hist, label="yaw")
    plt.plot(t, yaw_target_hist, label="yaw_target")
    plt.xlabel("t (s)")
    plt.ylabel("yaw (rad)")
    plt.grid(True)
    plt.legend()

    # Pitch
    plt.figure()
    plt.title("Pitch (rad)")
    plt.plot(t, pitch_hist, label="pitch")
    plt.plot(t, pitch_target_hist, label="pitch_target")
    plt.xlabel("t (s)")
    plt.ylabel("pitch (rad)")
    plt.grid(True)
    plt.legend()

    # Actuators
    plt.figure()
    plt.title("Actuators")
    plt.plot(t, rud_hist, label="rudder")
    plt.plot(t, stern_hist, label="stern")
    plt.plot(t, thrust_hist, label="thrust")
    plt.xlabel("t (s)")
    plt.ylabel("cmd")
    plt.grid(True)
    plt.legend()
    
    plt.figure()
    plt.title("Speed (m/s)")
    plt.plot(t, speed_hist, label='speed')
    plt.legend()
    plt.grid(True)

    for i, fig in enumerate(plt.get_fignums()):
        plt.figure(fig)
        plt.savefig(os.path.join(outdir, f"plot_{i+1}.png"), dpi=150)
    print("Saved plots to:", outdir)
    plt.show()

def main() -> None:
    """Entry point for the demo CLI."""
    ap = argparse.ArgumentParser()
    ap.add_argument("--duration", type=float, default=120.0)
    ap.add_argument("--scenario", choices=["cruise","speed_test"], default="cruise")
    args = ap.parse_args()
    cfg = load_settings()

    if args.scenario == "cruise":
        run_demo(cfg, args.duration)
    elif args.scenario == "speed_test":
        # Timeline: (time, speed in m/s)
        speed_profile = [
            (0, 0.0),    # start stopped
            (5, 5.5),    # accelerate to full speed (10+ kn)
            (40, 2.57),  # drop to ~5 kn
            (80, 0.0)    # stop
        ]
        run_demo(cfg, args.duration, speed_profile=speed_profile)

if __name__ == "__main__":
    main()

'''
# Cruise at setpoint speed
python -m subsim.run_simulation --scenario cruise

# Speed change test (0 → 10 kn → 5 kn → stop)
python -m subsim.run_simulation --scenario speed_test
'''